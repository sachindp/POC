package com.cg.web.mvc.tat.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.NamingException;

public class DBUtil 
{
	public static Connection getConnection() throws NamingException, SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tp","root","sunlife1");
		return con;
	}

}
