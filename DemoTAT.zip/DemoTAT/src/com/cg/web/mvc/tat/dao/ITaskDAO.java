package com.cg.web.mvc.tat.dao;

import java.util.List;

import com.cg.web.mvc.tat.dto.Task;
import com.cg.web.mvc.tat.exception.TaskException;

public interface ITaskDAO {

	public int addTask(Task task) throws TaskException;
	
	public void updateTask(Task task) throws TaskException;
	
	public Task removeTask(int taskId) throws TaskException;
	
	public Task viewTask(int taskId) throws TaskException;
	
	public List<Task> viewAllTasks() throws TaskException;
	
	public void login(String username, String password) throws TaskException;
	
}
