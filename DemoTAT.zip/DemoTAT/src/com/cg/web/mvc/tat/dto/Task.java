package com.cg.web.mvc.tat.dto;

import java.util.Date;

public class Task {

	private int taskId;
	private String appName;
	private String taskName;
	private String taskDesc;
	private Date startDate;
	private Date endDate;
	private String status;
	private String priority;
	private String offshoreOwner;
	private String onshoreOwner;
	private String comments;
	private String createdBy;
	private Date createdOn;
	private String updatedBy;
	private Date updatedOn;
	
	public Task() {
		super();
	}

	public Task(String appName, String taskName, String taskDesc, Date startDate, Date endDate, String status,
			String priority, String offshoreOwner, String onshoreOwner, String comments, String createdBy,
			Date createdOn, String updatedBy, Date updatedOn) {
		super();
		this.appName = appName;
		this.taskName = taskName;
		this.taskDesc = taskDesc;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.priority = priority;
		this.offshoreOwner = offshoreOwner;
		this.onshoreOwner = onshoreOwner;
		this.comments = comments;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
	}

	public Task(int taskId, String appName, String taskName, String taskDesc, Date startDate, Date endDate,
			String status, String priority, String offshoreOwner, String onshoreOwner, String comments,
			String createdBy, Date createdOn, String updatedBy, Date updatedOn) {
		super();
		this.taskId = taskId;
		this.appName = appName;
		this.taskName = taskName;
		this.taskDesc = taskDesc;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.priority = priority;
		this.offshoreOwner = offshoreOwner;
		this.onshoreOwner = onshoreOwner;
		this.comments = comments;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskDesc() {
		return taskDesc;
	}

	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getOffshoreOwner() {
		return offshoreOwner;
	}

	public void setOffshoreOwner(String offshoreOwner) {
		this.offshoreOwner = offshoreOwner;
	}

	public String getOnshoreOwner() {
		return onshoreOwner;
	}

	public void setOnshoreOwner(String onshoreOwner) {
		this.onshoreOwner = onshoreOwner;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", appName=" + appName + ", taskName=" + taskName + ", taskDesc=" + taskDesc
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", status=" + status + ", priority=" + priority
				+ ", offshoreOwner=" + offshoreOwner + ", onshoreOwner=" + onshoreOwner + ", comments=" + comments
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn="
				+ updatedOn + "]";
	}

}
