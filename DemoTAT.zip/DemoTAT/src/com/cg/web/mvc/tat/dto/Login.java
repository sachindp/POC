package com.cg.web.mvc.tat.dto;

public class Login {

	private int sNo;
	private String empId;
	private String password;
	
	public Login() {
		super();
	}

	public Login(int sNo, String empId, String password) {
		super();
		this.sNo = sNo;
		this.empId = empId;
		this.password = password;
	}

	public int getsNo() {
		return sNo;
	}

	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Login [sNo=" + sNo + ", empId=" + empId + ", password=" + password + "]";
	}
	
}
