package com.capgemini.hbms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="roomdetails")
public class RoomDetailsBean {
	
	@Column(name="hotel_id")
	private String hotelId;
	
	@Id
	@Column(name="room_id")
	private String roomId;
	
	@Column(name="room_no")
	private String roomNo;
	
	@Column(name="room_type")
	private String roomType;
	
	@Column(name="per_night_rate")
	private double perNightRate;
	
	@Column(name="availability")
	private String availability;
	
	@Lob
	@Column(name="photo")
	private byte[] photo;
	
	public RoomDetailsBean() {
		super();
	}

	public RoomDetailsBean(String hotelId, String roomId, String roomNo,
			String roomType, double perNightRate, String availability,
			byte[] photo) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
		this.availability = availability;
		this.photo = photo;
	}	
	
	public RoomDetailsBean(String hotelId, String roomId) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
	}
	

	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public double getPerNightRate() {
		return perNightRate;
	}

	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	@Override
	public String toString() {
		return "RoomDetailsBean [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability + ", photo=" + photo + "]";
	}
	
	
}

/*
hotel_id(varchar(4)),  room_id (varchar(4)),  room_no(varchar(3)), 
room_type(varchar(20)), per_night_rate (number(6,2)), 
availability (Boolean), photo (blob))*/
