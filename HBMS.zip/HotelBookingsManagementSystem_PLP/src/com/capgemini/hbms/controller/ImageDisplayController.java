package com.capgemini.hbms.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.RoomServiceImpl;

/**
 * Servlet implementation class ImageDisplayController
 */
@WebServlet("/image")
public class ImageDisplayController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ImageDisplayController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		System.out.println("Image");
		IRoomService roomService = new RoomServiceImpl();

		RoomDetailsBean roomDetailsBean = new RoomDetailsBean();

		byte[] image;
		try {
			roomDetailsBean = roomService.getRoomDetail(request
					.getParameter("id"));

			System.out.println(request.getParameter("id"));

			image = roomDetailsBean.getPhoto();
			if (image != null) {
				response.setContentType("image/jpg");

				OutputStream outputStream = response.getOutputStream();

				outputStream.write(image);
				outputStream.flush();
				outputStream.close();
			}
		} catch (HBMSException e) {

			System.out.println(e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
