package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class BookingDetailsDAOImpl implements IBookingDetailsDAO {

	@PersistenceContext
	private EntityManager entityManager;
	

	@Override
	public int bookHotelRoom(BookingDetailsBean bookingDetailsBean)
			throws HBMSException {

		int bookingId = 0;
		try{
			entityManager.persist(bookingDetailsBean);
			
			bookingId = bookingDetailsBean.getBookingId();
			
		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}

		return bookingId;

	}

	@Override
	public BookingDetailsBean getBookingDetail(int bookingId)
			throws HBMSException {
		
		BookingDetailsBean bookingDetailsBean = new BookingDetailsBean();
		try{
			bookingDetailsBean = entityManager.find(BookingDetailsBean.class,bookingId);

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return bookingDetailsBean;
	}

	@Override
	public List<BookingDetailsBean> getBookingDetails(String userId)
			throws HBMSException {

		List<BookingDetailsBean> bookingList = new ArrayList<BookingDetailsBean>();
		try{
			TypedQuery<BookingDetailsBean> qry = entityManager.createQuery("from BookingDetailsBean where userId=:id",BookingDetailsBean.class);
			qry.setParameter("id",userId);
			
			bookingList = qry.getResultList();
			
		} catch (Exception e) {
			
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return bookingList;
	}

}
