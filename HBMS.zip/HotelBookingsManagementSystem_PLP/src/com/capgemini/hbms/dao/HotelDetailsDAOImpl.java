package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class HotelDetailsDAOImpl implements IHotelDetailsDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public List<HotelDetailsBean> viewHotels() throws HBMSException {


		List<HotelDetailsBean> hotelsList = new ArrayList<HotelDetailsBean>();
		
		try{
			TypedQuery<HotelDetailsBean> qry = entityManager.createQuery("from HotelDetailsBean",HotelDetailsBean.class);
			
			hotelsList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
		return hotelsList;
	}

	@Override
	public HotelDetailsBean viewHotel(String hotelId) throws HBMSException {

		HotelDetailsBean hotelDetailsBean = null;
		
		try{
			hotelDetailsBean = entityManager.find(HotelDetailsBean.class,hotelId);
			
		} catch(Exception e){

			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
		return hotelDetailsBean;
	}

	

}
