package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class RoomDetailsDAOImpl implements IRoomDetailsDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<String> getAllRoomIds() throws HBMSException {
		
		List<String> roomIdList = new ArrayList<String>();

		try {
			TypedQuery<String> qry = entityManager.createQuery("select roomId from RoomDetailsBean",
					String.class);

			roomIdList = qry.getResultList();

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomIdList;
	}

	@Override
	public double getRoomRate(String roomId) throws HBMSException {

		RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
		double roomRate = 0;
		try {
			roomDetailsBean = entityManager.find(RoomDetailsBean.class, roomId);
			roomRate = roomDetailsBean.getPerNightRate();
		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomRate;
	}

	@Override
	public List<RoomDetailsBean> getRoomHotelID() throws HBMSException {

		List<RoomDetailsBean> roomHotelIDList = new ArrayList<RoomDetailsBean>();

		try {
			TypedQuery<RoomDetailsBean> qry = entityManager.createQuery("select hotelId,roomId from RoomDetailsBean",
					RoomDetailsBean.class);

			roomHotelIDList = qry.getResultList();

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomHotelIDList;
	}

	@Override
	public RoomDetailsBean getRoomDetail(String roomId) throws HBMSException {

		RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
		try {
			roomDetailsBean = entityManager.find(RoomDetailsBean.class, roomId);

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomDetailsBean;
	}

	@Override
	public List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException {

		List<RoomDetailsBean> listOfRooms = new ArrayList<RoomDetailsBean>();

		try {
			TypedQuery<RoomDetailsBean> qry = entityManager.createQuery("from RoomDetailsBean where hotelId = :id",
					RoomDetailsBean.class);
			qry.setParameter("id", hotelId);

			listOfRooms = qry.getResultList();
		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return listOfRooms;
	}
}
