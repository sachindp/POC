package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserDetailsDAO {
	
	int RegisterUser(UserDetailsBean userDetails) 
			throws HBMSException;

	
	List<UserDetailsBean> usersDetail() throws HBMSException;
	
	
}