package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHotelDetailsDAO {
	
	List<HotelDetailsBean> viewHotels() throws HBMSException;
	
	HotelDetailsBean viewHotel(String hotelId) throws HBMSException;

}
