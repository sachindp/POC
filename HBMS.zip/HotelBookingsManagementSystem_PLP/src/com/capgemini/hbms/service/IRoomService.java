package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IRoomService {

	public RoomDetailsBean getRoomDetail(String roomId) throws HBMSException;
	
	boolean isRoomIdValid(String roomId, String hotelId) throws HBMSException;
	
	public double getRoomRate(String roomId) throws HBMSException;
	
	List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException;

}
