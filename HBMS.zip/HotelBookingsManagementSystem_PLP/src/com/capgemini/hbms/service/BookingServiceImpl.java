package com.capgemini.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.dao.IBookingDetailsDAO;
import com.capgemini.hbms.exception.HBMSException;

@Service
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IBookingDetailsDAO bookingDetailsDao;
	
	@Override
	public BookingDetailsBean getBookingDetail(int bookingId) throws HBMSException {
		
		return bookingDetailsDao.getBookingDetail(bookingId);
	}
	
	@Override
	public int bookHotelRoom(BookingDetailsBean bookingDetailsBean)
			throws HBMSException {
	
		return bookingDetailsDao.bookHotelRoom(bookingDetailsBean);
	}

	@Override
	public List<BookingDetailsBean> getBookingDetails(String userId)
			throws HBMSException {
		List<BookingDetailsBean> bookingList = bookingDetailsDao.getBookingDetails(userId);
		return bookingList;
	}

}
